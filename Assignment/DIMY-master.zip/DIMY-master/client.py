import socket
import pickle
from bloom_filter2 import BloomFilter
import shamir
import sys

#tcp client

# create a socket object
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM) 

# get local machine name
host = socket.gethostname()                      
tcp_server_port = 9999 

# connection to hostname on the port.
s.connect((host, tcp_server_port))                               

# Receive no more than 1024 bytes
msg = s.recv(1024)                                     

s.close()
print (msg.decode('ascii'))


#TODO implement UDP client/server on condition

msgFromServer = "Hello UDP Client"
bytesToSend = str.encode(msgFromServer)

#setup server port 
udp_server_port = sys.argv[1]

UDPServerSocket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
UDPServerSocket.bind((host, udp_server_port))
print("UDP server up and listening")

while(True):

    bytesAddressPair = UDPServerSocket.recvfrom(1024)

    message, address = bytesAddressPair[0], bytesAddressPair[1]

    clientMsg = "Message from Client:{}".format(message)
    clientIP  = "Client IP Address:{}".format(address)
    
    print(clientMsg)
    print(clientIP)

    UDPServerSocket.sendto(bytesToSend, address)


#TODO BLOOM FILTER

# instantiate BloomFilter with custom settings,
# max_elements is how many elements you expect the filter to hold.
# error_rate defines accuracy; You can use defaults with
# `BloomFilter()` without any arguments. Following example
# is same as defaults:
bloom = BloomFilter(max_elements=10000, error_rate=0.1)

# Test whether the bloom-filter has seen a key:
assert "test-key" not in bloom

# Mark the key as seen
bloom.add("test-key")

# Now check again
assert "test-key" in bloom


