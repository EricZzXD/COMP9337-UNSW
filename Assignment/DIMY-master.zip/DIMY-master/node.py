from diffiehellman.diffiehellman import DiffieHellman
import socket
import _thread
import random
import time
import pickle
from pybloom import BloomFilter
from shamirsecret import generate_shares, reconstruct_secret
import sys
import os


covid_node = int(sys.argv[3])

udp_server_port = int(sys.argv[1])
udp_broadcast_ports = [1234, 1235, 1236]
udp_listen_port = udp_broadcast_ports.pop(int(sys.argv[2]))
host = '127.0.0.1'
UDPServerSocket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)


UDPClientSocket = socket.socket(family=socket.AF_INET, type=socket.SOCK_DGRAM)
UDPClientSocket.bind((host, udp_listen_port))
UDPClientSocket.settimeout(2.0)
   

DBF = BloomFilter(capacity=1000, error_rate=0.001)
DBFList = []
shareBuffer = {}
receiver_diffie = {}

def pingBroadcast():

    while True:
        sephID = int.from_bytes(os.urandom(16), 'little')
        print('Segment 1: generating EphID', str(sephID)[:5])
        shares = generate_shares(5, 3, sephID)

        display_share = [i[0] for i in shares]
        print('Segment 2: share pieces', display_share)
        for share_piece in shares:
            if random.uniform(0, 1) < 0.5:
                print('Segment 3-A: dropped share', share_piece[0])
                time.sleep(3)
                continue
            senderTuple = ('share', share_piece, sephID.__hash__(), udp_listen_port)
            print('Segment 3-A: broadcasting share', share_piece[0])
            UDPServerSocket.sendto(pickle.dumps(senderTuple), (host, udp_broadcast_ports[0]))
            UDPServerSocket.sendto(pickle.dumps(senderTuple), (host, udp_broadcast_ports[1]))
            time.sleep(3)


_thread.start_new_thread(pingBroadcast, ())
start_time = time.time()
elapsed_time = start_time
print('listening on port', udp_listen_port)

dbf_sample_time = 90
sample_time = 550
status = 'QBF'
if covid_node == 1:
    status = 'CBF'
    sample_time = 530

while True:

    if time.time() - elapsed_time > dbf_sample_time: #every 90 second interval
        elapsed_time = time.time()
        DBFList.append(DBF)
        DBF = BloomFilter(capacity=1000, error_rate=0.001)
        print('Segment 7-B: new DBF every 90 seconds')
    
    if time.time() - start_time > sample_time: #after 9 mins (currently only 3)
        while len(DBFList) > 6: #keep removing BF until len is 6
            print('Segment 7-B: more than 6 DBFs, discarding old')
            DBFList.pop(0)

        QBF = BloomFilter(capacity=1000, error_rate=0.001)
        for dbf in DBFList:
            print('Segment 8: combining DBFs into QBF', QBF.bitarray.count())
            QBF = QBF.union(dbf)

        print('Segment 9: uploading to backend', QBF.bitarray.count())
        TCPClientSocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM) 
        TCPClientSocket.connect((host, 9998))
        TCPClientSocket.sendall(pickle.dumps((status, QBF)))
        print('Segment 10-A: upload complete', QBF.bitarray.count())
        msg = TCPClientSocket.recv(50000)
        msgrecved = pickle.loads(msg)
        print('Segment 10-B: reply received', msgrecved)
        break

    try:    
        byteAddress = UDPClientSocket.recvfrom(1024) #set 2 second timeout
    except: #timeout
        continue

    bytes, address = byteAddress[0], byteAddress[1]
    messageTuple = pickle.loads(bytes)
    type = messageTuple[0]

    if type == 'receiverPG': # you were the sender (of the broadcasted shares)
        group, receiverPubKey = messageTuple[1], messageTuple[2]
        sender_diffie = DiffieHellman(group, key_length=200)
        sender_diffie.generate_public_key()
        try:
            print('Segment 5-A: computing shared secret with receiver pubkey', str(receiverPubKey)[:5])
            sender_diffie.generate_shared_secret(receiverPubKey)
            encID = sender_diffie.shared_key
            print('Segment 5-B: arriving at shared secret (encID)', str(encID)[:5])
            DBF.add(encID)
            print('Segment 6: encoding and deleting encID', str(encID)[:5])
            print('Segment 7-A: number of encIds and count of 1s ', str(DBF.count), str(DBF.bitarray.count()))
            sendTuple = ('senderPub', sender_diffie.public_key, udp_listen_port)
            UDPClientSocket.sendto(pickle.dumps(sendTuple), address)
        except:
            print('bad pub key, not adding to bf')

    elif type == 'senderPub':  # you were the receiver (of the broadcasted shares)
        senderPubKey, senderPort = messageTuple[1], messageTuple[2]
        if receiver_diffie.get(senderPort) != None:
            try:
                print('Segment 5-A: computing shared secret with broadcaster pubkey', str(senderPubKey)[:5])
                receiver_diffie[senderPort].generate_shared_secret(senderPubKey)
                encID = receiver_diffie[senderPort].shared_key
                print('Segment 5-B: arriving at shared secret (encID)', str(encID)[:5])
                DBF.add(encID)
                print('Segment 6: encoding and deleting encID', str(encID)[:5])
                print('Segment 7-A: number of encIds and count of 1s ', str(DBF.count), str(DBF.bitarray.count()))

            except:
                receiver_diffie[senderPort] = None
                print('bad pubkey, clearing intialisation cache') 
        else:
            print('did not intialise public key for this exchange')

    elif type == 'share': #you are the reciever
        share, ephIDHash, port = messageTuple[1], messageTuple[2], messageTuple[3]
        address = (host, port)
        print('Segment 3-B: received a share', share[0])

        if shareBuffer.get(port) == None:
            shareBuffer[port] = []
        shareBuff = shareBuffer[port]
        if len(shareBuff) == 2 and (ephIDHash != shareBuff[0][1] or ephIDHash != shareBuff[1][1]) :
            print('Segment 3-C: discarding shares not enough match', share[0])
            shareBuff.pop(0)
            shareBuff.append((share, ephIDHash))
            continue
        elif len(shareBuff) == 2: #hashes match
            print('Segment 4-A: 3 shares match, attempting reconstruction...')
            pool = [shareBuff[0][0], shareBuff[1][0], share]
            ephID = reconstruct_secret(pool)
            computedHash = ephID.__hash__()
            if computedHash != ephIDHash: #reconstructed ephId doesnt match hash drop oldest
                print('Segment 4-B: recreated ephID hash mismatch, dropping')
                shareBuff.pop(0)
                shareBuff.append((share, ephIDHash))
                continue
            print('Segment 4-B: Passed reconstruction hash check', str(computedHash)[:5],str(ephIDHash)[:5])
            shareBuffer[port] = []
            group = random.choice([5,14,15,17])
            receiver_diffie[port] = DiffieHellman(group=group, key_length=200)
            receiver_diffie[port].generate_public_key()
            sendTuple = ('receiverPG', group, receiver_diffie[port].public_key)
            UDPClientSocket.sendto(pickle.dumps(sendTuple), address)

        else: 
            shareBuff.append((share, ephIDHash))
