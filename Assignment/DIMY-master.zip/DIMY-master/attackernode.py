import socket
import random
import time
import pickle
import sys
import os


# Takes in server port, and node number


udp_broadcast_ports = [1234, 1235]
host = '127.0.0.1'

attackerSocket = socket.socket(family=socket.AF_INET, type=socket.SOCK_DGRAM)
attackerSocket.bind((host, 8887))


start_time = time.time()
while time.time() - start_time < 70:

    for port in udp_broadcast_ports: #port is target port
        impersonate_ports = udp_broadcast_ports.copy()
        impersonate_ports.remove(port) #rm sending port from list to impersonate other port
        msgtuple1 = ('receiverPG', 5, os.urandom(16)) #impersonate receiving 3 shares 
        msgtuple2 = ('senderPub', os.urandom(16), impersonate_ports[0]) 
        #impersonate being a broadcaster, sending back pub key, spoof port
        print('Segment 11-A: sending spoof and flood attack')
        attackerSocket.sendto(pickle.dumps(msgtuple1), (host, port))
        attackerSocket.sendto(pickle.dumps(msgtuple2), (host, port))
