import socket
import _thread
import pickle
from pybloom import BloomFilter
import sys

#tcp server

# create a socket object
serversocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM) 
#change second paramater to DGRAM for UDP packet

# get local machine name
host = '127.0.0.1'                         
port = 9998                                           

encIDrepo = {}

# bind to the port
serversocket.bind((host, port))                                  

# queue up to 2 requests
serversocket.listen(5) 

CBF = BloomFilter(capacity=1000, error_rate=0.001)




def uploadEnc(clientsocket, addr):
	global CBF
	print("Got a connection from %s" % str(addr))
	bytes = clientsocket.recv(50000)
	BFtuple = pickle.loads(bytes)
	BF = BFtuple[1]
	if BFtuple[0] == 'CBF':
		CBF = BF
		clientsocket.send(pickle.dumps('uploaded CBF'))
	else:
		encIDrepo[addr[1]] = BF
		interesctionValue = CBF.intersection(BF).bitarray.count()
		print('Segment 10-C: received QBF performing risk analysis', interesctionValue)
		matchingresult = 'Unmatched'
		if interesctionValue > 0:
			matchingresult = 'Matched'
		pickledump = pickle.dumps(('intersection ', matchingresult))

		clientsocket.send(pickledump)
	clientsocket.close()
	return


count = 0
while count < int(sys.argv[1]):
   # establish a connection
	print('waiting for connection')
	clientsocket, addr = serversocket.accept()      
	_thread.start_new_thread(uploadEnc, (clientsocket, addr))
	count += 1



