import random
from math import ceil
from decimal import Decimal, setcontext, Context
import os
 
FIELD_SIZE = 10**8
 
 
def reconstruct_secret(shares):
    """
    Combines individual shares (points on graph)
    using Lagranges interpolation.
 
    `shares` is a list of points (x, y) belonging to a
    polynomial with a constant of our key.
    """
    sums = 0
    prod_arr = []
    setcontext(Context(prec=60))
    for j, share_j in enumerate(shares):
        xj, yj = share_j
        prod = Decimal(1)
 
        for i, share_i in enumerate(shares):
            xi, _ = share_i
            if i != j:
                prod *= Decimal(Decimal(xi)/(xi-xj))
 
        prod *= yj
        sums += Decimal(prod)
 
    return int(round(Decimal(sums), 0))
 
 
def polynom(x, coefficients):
    """
    This generates a single point on the graph of given polynomial
    in `x`. The polynomial is given by the list of `coefficients`.
    """
    point = 0
    # Loop through reversed list, so that indices from enumerate match the
    # actual coefficient indices
    for coefficient_index, coefficient_value in enumerate(coefficients[::-1]):
        point += x ** coefficient_index * coefficient_value
    return point
 
 
def coeff(t, secret):
    """
    Randomly generate a list of coefficients for a polynomial with
    degree of `t` - 1, whose constant is `secret`.
 
    For example with a 3rd degree coefficient like this:
        3x^3 + 4x^2 + 18x + 554
 
        554 is the secret, and the polynomial degree + 1 is
        how many points are needed to recover this secret.
        (in this case it's 4 points).
    """
    coeff = [random.randrange(0, FIELD_SIZE) for _ in range(t - 1)]
    coeff.append(secret)
    return coeff
 
 
def generate_shares(n, m, secret):
    """
    Split given `secret` into `n` shares with minimum threshold
    of `m` shares to recover this `secret`, using SSS algorithm.
    """
    coefficients = coeff(m, secret)
    shares = []
 
    for i in range(1, n+1):
        x = random.randrange(1, FIELD_SIZE)
        shares.append((x, polynom(x, coefficients)))
 
    return shares

 # Driver code
if __name__ == '__main__':
    original = 218580035471928453205344893029049502915
    receivedpool = [(49397278, 507657359229901515765239274901570952687), (48403305, 485082984458195514726679254279116485770), (69088856, 1324780806675976969316564833517212299619)]
    
    originalfullpool = generate_shares(3, 5, original)
    print('orignal and received pools are')
    print(originalfullpool)
    print(receivedpool)

    recreated = reconstruct_secret(receivedpool)
    print('orignal and recreated are: ', original, recreated)
    if original != recreated:
        print('mismatch key')
    else:
        print('match key')

    # for i in range(0,5):
    # # (3,5) sharing scheme
    #     t, n = 3, 5
    #     secret = int.from_bytes(os.urandom(16), 'little')
    #     #print(f'Original Secret: {secret}')
    
    #     # Phase I: Generation of shares
    #     shares = generate_shares(n, t, secret)
    #     #print(f'Shares: {", ".join(str(share) for share in shares)}')
    
    #     # Phase II: Secret Reconstruction
    #     # Picking t shares randomly for
    #     # reconstruction
    #     pool = random.sample(shares, t)
    #     #print(f'Combining shares: {", ".join(str(share) for share in pool)}')
    #     #print(f'Reconstructed secret: {reconstruct_secret(pool)}')
    #     reconstructed = reconstruct_secret(shares[0:3])
    #     print('secret and recon', secret, reconstructed)
    #     if secret != reconstructed:
    #         print("different secret reconstructed: ", secret, reconstructed)


        